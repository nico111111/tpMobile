package com.example.myapplication

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.AlarmClock.EXTRA_MESSAGE
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class ActivityAddToDo : AppCompatActivity() {

    var backButton : Button? = null
    var addButton : Button? = null
    var titreText : EditText? = null
    var descText : EditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_to_do)

        backButton = findViewById(R.id.backButtonAdd)
        addButton = findViewById(R.id.buttonAdd)
        titreText = findViewById(R.id.titreAdd)
        descText = findViewById(R.id.defAdd)

        backButton?.setOnClickListener{
            finishWithError()
        }

        addButton?.setOnClickListener{
            if(TextUtils.isEmpty(titreText?.text.toString())){
                Toast.makeText(this, "Titre ne peut pas etre vide", Toast.LENGTH_SHORT).show()
            }else{
                val textResult = titreText?.text.toString() + " " + descText?.text.toString()
                val data = Intent().apply {
                    putExtra(EXTRA_MESSAGE, textResult)
                }
                setResult(Activity.RESULT_OK, data)
                finish()
            }

        }
    }

    fun finishWithError(){
        finish()
        // ligne fonctionne apres le finish
        Toast.makeText(this, "Ajout d'un item annulé", Toast.LENGTH_SHORT).show()

    }
}